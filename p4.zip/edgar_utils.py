import pandas as pd
import re
import netaddr
from bisect import bisect

ip_location_df = pd.read_csv("ip2location.csv")
ip_low_values = ip_location_df["low"].tolist()

def lookup_region(ips):
    ip_str = re.sub(r'[a-zA-Z]', '0', ips)
    ip_int = int(netaddr.IPAddress(ip_str))
    idx = bisect(ip_low_values, ip_int) - 1 
    return ip_location_df.at[idx, "region"]
                                 
                                 
class Filing:
    def __init__(self, html):
        self.dates = self.extract_dates(html)
        self.sic = self.extract_sic(html)
        self.addresses = self.extract_addresses(html)

    def extract_dates(self, html):
        date_pattern = r"\b\d{4}-\d{2}-\d{2}\b"
        return re.findall(date_pattern, html)

    def extract_sic(self, html):
        sic_pattern = r"SIC=(\d+)"
        match = re.search(sic_pattern, html)
        return int(match.group(1)) if match else None

    def extract_addresses(self, html):
        addresses = []
        for addr_html in re.findall(r'<div class="mailer">([\s\S]+?)</div>', html):
            lines = []
            for line in re.findall(r'<span class="mailerAddress">([\s\S]+?)</span>', addr_html):
                lines.append(line.strip())
            if len(lines) >= 1:
                
                addresses.append('\n'.join(lines))
        return addresses

    def state(self):
        state_pattern = r'\b[A-Z]{2}(?=\s\d{5}(?:-\d{4})?\b)'
        for address in self.addresses:
            match = re.search(state_pattern, address)
            if match:
                return match.group(0)
        return None
    
    





