# project: p4
# submitter: hhess3
# partner: none
# hours: 14

import pandas as pd
from flask import Flask, request, jsonify, Response, render_template, redirect, url_for
import zipfile
import time
import edgar_utils
import pandas as pd
import edgar_utils
from edgar_utils import *
import re
from zipfile import ZipFile
from collections import defaultdict
import geopandas as gpd
import matplotlib.pyplot as plt
from graphviz import Graph, Digraph
from shapely.geometry import Point, Polygon, box
from io import TextIOWrapper

app = Flask(__name__)
# df = pd.read_csv("main.csv")

count = 0 
count_a = 0
count_b = 0

@app.route('/')
def home():
    global count, count_a, count_b
    with open("index.html") as f:
        html = f.read()

    modified_html = html.replace("from=A", "from=B").replace('color: green', 'color: red')

    if count < 10:
        if count % 2 == 0:
            count += 1
            return html  # Display version A
        else:
            count += 1
            return modified_html  # Display version B
    else:
        # After 10 visits, show the version that has been visited more frequently
        if count_a > count_b:
            count += 1
            return html
        else:
            count += 1
            return modified_html
        
@app.route('/browse.html')
def browse_html():
    zf = zipfile.ZipFile("server_log.zip")
    f = zf.open("rows.csv")
    df = pd.read_csv(f)
    f.close()
    zf.close()
    return "<html>{}<html>".format("<h1> Browse first 500 rows of rows.csv</h1>" + df[:500].to_html())
    
visitors = []
times = {}

@app.route('/browse.json')
def browse_json():
    global visitors, times
    zf = zipfile.ZipFile("server_log.zip")
    f = zf.open("rows.csv")
    df = pd.read_csv(f)
    f.close()
    zf.close()
    
    rate = 60
    ip = request.remote_addr
    visitors.append(ip)
    now = time.time()

    if ip in times:
        td = now - times[ip]
        if td < rate:
            return Response("Please come back in " + str(rate - td) + " seconds.", status=429, headers={"Retry-After": str(rate)})
        else:
            times[ip] = now
    else:
        times[ip] = now
        
    return jsonify(df[:500].to_dict())

@app.route('/visitors.json')
def visited_ips():
    return visitors 

@app.route('/donate.html')
def donate_html():
    global count_a, count_b
    from_version = request.args.get("from")
    if from_version == 'A':
        count_a += 1
    elif from_version == 'B': 
        count_b += 1
                                                      
    return "<html>{}<html>".format("<h2> Please consider donating to our cause </h2>")
    

@app.route('/analysis.html')
def analysis_html():
    return f"""
    <h1>Analysis of EDGAR Web Logs</h1>
    <p>Q1: how many filings have been accessed by the top ten IPs?</p>
    <p>{str(q1())}</p>
    <p>Q2: what is the distribution of SIC codes for the filings in docs.zip?</p>
    <p>{str(q2())}</p>
    <p>Q3: what are the most commonly seen street addresses?</p>
    <p>{str(q3())}</p>
    <h4>Dashboard: geographic plotting of postal code</h4>
    <img src="dashboard.svg">
    """

def q1():
    csv = pd.read_csv('server_log.zip', compression="zip")
    top_ten_ips_dict = csv['ip'].value_counts()[:10].to_dict()
    return top_ten_ips_dict

def q2():
    filing_dict = {}
    with ZipFile('docs.zip', 'r') as myzip:
        file_infos = myzip.infolist()
    file_names = []
    for file in file_infos:
        file_names.append(file.filename)
        
    good_files = []
    for file in file_names:
        if "htm" in file:
            good_files.append(file)
    
    sic_list = []  
    
    with ZipFile('docs.zip', 'r') as f:
        for file in good_files:
            with f.open(file, "r") as x:
                filing = Filing(x.read().decode("utf-8"))
                sic = filing.sic
                if sic is not None:
                    sic_list.append(sic)  
    
    result = pd.Series(sic_list).value_counts().head(10).to_dict()
    
    return result

def q3():
    csv = pd.read_csv('server_log.zip', compression = "zip")
    csv["path"] = csv["cik"].astype('int32').astype('str') + "/" + csv["accession"].astype('str') + "/" + csv["extention"]
    path_list = csv["path"].to_list()

    filing_dict = {}
    with ZipFile('docs.zip', 'r') as myzip:
        file_infos = myzip.infolist()
        file_names = []
        for file in file_infos:
            file_names.append(file.filename)
        
    good_files = []
    for file in file_names:
        if "htm" in file:
            good_files.append(file)

    html_dict = {}
    with ZipFile('docs.zip', 'r') as f:
        for file in good_files:
            with f.open(file, "r") as x:
                filing = Filing(x.read().decode("utf-8"))
                html_dict[file] = filing
                    

    address_dict = {}
    for path in path_list:
        if path in html_dict.keys():
            addresses = html_dict[path].addresses
            for address in addresses:
                if address not in address_dict.keys():
                    address_dict[address] = 1
                else:
                    address_dict[address] += 1

    sorted_address_dict = dict(sorted(address_dict.items(), key=lambda x: x[1], reverse=True))
    large_address_dict = {}
    for key, val in sorted_address_dict.items():
        if val >= 300:
            large_address_dict[key] = val
    return large_address_dict

@app.route("/dashboard.svg")
def dash():
    with open("dashboard.svg") as f:
        return Response(f.read(), headers={"Content-Type": "image/svg+xml"})

if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, threaded=False)  # don't change this line!

    
# NOTE: app.run never returns (it runs for ever, unless you kill the process)
# Thus, don't define any functions after the app.run call, because it will
# never get that far.

   